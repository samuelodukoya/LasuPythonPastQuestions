# Python supports several types of functions, including:

# Built-in functions: These are functions that are already defined in the Python language and can be used without importing any additional modules. Examples of built-in functions include len, print, int, float, and str.

# User-defined functions: These are functions that are defined by the programmer. They can be used to perform specific tasks and can be reused throughout the code.

# Anonymous functions (lambda functions): These are small, one-time use functions that are defined using the lambda keyword. They are useful for simple operations that don't need to be named.

# Here's an example that demonstrates the use of the three types of functions in Python:


# Built-in function example:
print(len("Hello World!")) # Output: 12

# User-defined function example:
def multiply(a, b):
    return a * b

result = multiply(3, 4)
print(result) # Output: 12

# Anonymous function example:
squared = lambda x: x**2
result = squared(3)
print(result) # Output: 9


#In the example, the built-in function "len" is used to find the length of a string, the user-defined function "multiply" is used to multiply two numbers, and the anonymous function "squared" is used to square a number.