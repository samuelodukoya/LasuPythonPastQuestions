#i

#Here's a function that takes two parameters, both of which are numbers, and returns the absolute value of the difference of the two:

def absolute_difference(num1, num2):
    return abs(num1 - num2)

#The function absolute_difference takes two parameters num1 and num2, which are the two numbers. The function uses the built-in abs function to find the absolute value of the difference num1 - num2, and returns the result.

#ii

#Here's a function that takes one parameter, a number, and returns that number tripled:

def triple_number(num):
    return num * 3

#The function triple_number takes one parameter num, which is the number to be tripled. The function returns the result of num * 3, which is the tripled value of the input number.

