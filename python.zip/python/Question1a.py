#Write An Example of each of 
# the following:

# (String Constant)
#In Python, string constants are sequences of characters enclosed in quotes, 
#either single quotes ('') or double quotes ("""). Here's an example:

sentence = "Hello, how are you today?"
greeting = 'Good morning!'


# (Numeric Constant)
#In Python, numeric constants 
#can be either integers, floating-point 
#numbers, or complex numbers. Here are some examples:

integer_constant = 42
floating_point_constant = 3.14
complex_constant = 3 + 4j


# (Numeric Expression)
#A numeric expression is a combination of numeric 
# constants and operators that evaluates to a single 
# numeric value. Here are some examples of numeric 
# expressions in Python:

# Arithmetic operations
expression1 = 2 + 3
expression2 = 4 * 5
expression3 = 6 / 2
expression4 = 8 - 9

# Comparison operations
expression5 = 2 < 3
expression6 = 4 >= 4
expression7 = 5 == 5
expression8 = 6 != 7

#Note that comparison operations return a 
# boolean value (either True or False), while 
# arithmetic operations return a numeric value.


# ( String Expression )
#A string expression in Python is a 
# combination of string constants and 
# operators that evaluates to a single string value. 
# Here are some examples of string expressions in Python:

# Concatenation
expression1 = "Hello, " + "world!"
expression2 = "Hi" + ", there!"

# Repetition
expression3 = "Ha!" * 3
expression4 = "Na" * 5

# Type conversion
expression5 = str(3.14)
expression6 = "The answer is " + str(42)

#Note that when concatenating strings, you need to make sure 
# that both operands are of type string, otherwise you'll get a 'TypeError'. 
# In such cases, you can use the str() function to convert a non-string value 
# to a string before concatenating it.


# (Logical Expression)
#A logical expression in Python is a combination of 
# boolean values (True and False) and logical operators 
# (and, or, not) that evaluates to a single boolean value. 
# Here are some examples of logical expressions in Python:

# Logical "and"
expression1 = (2 < 3) and (4 > 3)
expression2 = (1 == 1) and (2 == 3)

# Logical "or"
expression3 = (2 < 3) or (4 < 3)
expression4 = (1 == 1) or (2 == 3)

# Logical "not"
expression5 = not (2 < 3)
expression6 = not (1 == 2)


