#i
#Here's an example of how to print the length of a list in Python:

fruits = ["apple", "banana", "cherry"]
print(len(fruits)) # Output: 3

# In this example, the list fruits contains three items. To get the length of the list, we use the built-in len function, which takes a sequence (e.g. list, tuple, string) as its argument and returns the number of items in the sequence.

# You can use the len function with any sequence in Python, not just lists.


#ii
#Here's an example of how to print the maximum value of a tuple with integer values in Python:

numbers = (1, 2, 3, 4, 5)
print(max(numbers)) # Output: 5

# In this example, the tuple numbers contains five integer values. To get the maximum value of the tuple, we use the built-in max function, which takes an iterable (e.g. list, tuple, string) as its argument and returns the maximum value in the iterable.

# You can use the max function with any iterable in Python that contains only values that can be compared to each other (e.g. integers, floats, strings).