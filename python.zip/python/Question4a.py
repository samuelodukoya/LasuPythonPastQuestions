# Lists and tuples are two data structures in Python that are used to store collections of items. While they are similar in many ways, there are several key differences between lists and tuples:

# Mutability: Lists are mutable, which means you can add, remove, or modify items in a list after it has been created. Tuples, on the other hand, are immutable, which means once a tuple is created, you cannot modify its items.

# Syntax: Lists are defined using square brackets [] and items are separated by commas. Tuples are defined using parentheses () and items are separated by commas.

# Here are some examples to illustrate the differences between lists and tuples:

# Defining a list
fruits = ["apple", "banana", "cherry"]
print(fruits) # Output: ['apple', 'banana', 'cherry']

# Modifying a list item
fruits[1] = "pear"
print(fruits) # Output: ['apple', 'pear', 'cherry']

# Defining a tuple
numbers = (1, 2, 3)
print(numbers) # Output: (1, 2, 3)

# Attempting to modify a tuple item
numbers[1] = 4 # This will raise a TypeError, since tuples are immutable

# In summary, lists are a flexible data structure that allows you to modify the items, while tuples are a more rigid data structure that do not allow you to modify the items after they have been created.