#Here's a function that computes the sum of all the numbers in a list:

def sum_of_numbers(numbers):
    total = 0
    for num in numbers:
        total += num
    return total

# The function sum_of_numbers takes one parameter numbers, which is a list of numbers. The function uses a for loop to iterate through each number in the list and adds it to the total variable. Finally, the function returns the sum of all the numbers in the list.

# Here's an example of how to use the function with the sample list [100, 200, 300, 400, 500]:

sample = [100, 200, 300, 400, 500]
result = sum_of_numbers(sample)
print(result) # Output: 1500

