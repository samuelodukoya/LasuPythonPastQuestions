# Here's an example of how to capture ten surnames in random order, append each name to a list, sort and print the ordered list using a loop construct in Python:

surnames = []

for i in range(10):
    surname = input("Enter surname {}: ".format(i + 1))
    surnames.append(surname)

surnames.sort()
print("Ordered list of surnames:", surnames)


# In this example, we use a for loop to capture ten surnames and append each surname to a list called surnames. We use the input function to allow the user to enter each surname.

# After capturing all ten surnames, we use the sort method to sort the list in ascending order. Finally, we use the print function to display the ordered list of surnames.