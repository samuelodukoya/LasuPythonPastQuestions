import math

def quadratic_equation(a, b, c):
    """
    Solves the quadratic equation ax^2 + bx + c = 0.
    Returns a tuple of two real roots, or None if there are no real roots.
    """
    discriminant = b**2 - 4*a*c
    if discriminant < 0:
        return None
    elif discriminant == 0:
        x = -b / (2 * a)
        return (x, )
    else:
        x1 = (-b + math.sqrt(discriminant)) / (2 * a)
        x2 = (-b - math.sqrt(discriminant)) / (2 * a)
        return (x1, x2)


# The quadratic_equation function takes three arguments a, b, and c, which are the coefficients of the quadratic equation ax^2 + bx + c = 0. The function returns a tuple of real roots of the equation, or None if there are no real roots.

