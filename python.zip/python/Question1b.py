#Write the python programming language
#equivalent of the following mathematical 
#equations:

# i
import math

def techadot(a, b, c):
    Z = a * pow(X,2) + (bX + c)
    return Z

# ii
import math

def  techie(u,t,a):
    S = ( u * t ) + (( a * (t**2)) / 2)